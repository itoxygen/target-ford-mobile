package com.mtu.ito.fotaito.data.pojos;

/**
 * Created by Kyle on 11/9/2014.
 */
public class WeeklyAdOffer {
}
