package com.mtu.ito.fotaito.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Created by Kyle on 11/1/2014.
 */
public class BluetoothService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
