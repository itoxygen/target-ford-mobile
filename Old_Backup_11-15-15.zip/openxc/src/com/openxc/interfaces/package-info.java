/**
 * The interfaces and implementation of vehicle interfaces, capable of sending
 * data from an application to the vehicle.
 */
package com.openxc.interfaces;
