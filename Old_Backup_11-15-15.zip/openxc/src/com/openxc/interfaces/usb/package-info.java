/**
 * Contains a vehicle data source that connects to a vehicle interface via USB.
 * This is the default vehicle data source.
 */
package com.openxc.interfaces.usb;
