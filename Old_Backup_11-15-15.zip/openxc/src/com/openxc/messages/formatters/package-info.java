/**
 * Classes capable of serializing and deserializing VehicleMessage instances.
 */
package com.openxc.messages.formatters;
