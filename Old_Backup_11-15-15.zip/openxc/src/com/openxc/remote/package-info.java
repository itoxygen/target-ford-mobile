/**
 * Provides a centralized process, exposed as an Android service, to control
 * access to measurements from the vehicle.
 */
package com.openxc.remote;
